
public class TurtleTest {

	public static void main(String[] args) {
		Turtle t = new Turtle();
		t.forward(50);
	}
}
